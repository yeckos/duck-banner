# DUCK BANNER 🦆

Banner del pato low-poly azul hecho con letras y numeros (ASCII Art) para Linux.

## Uso rapido

```bash
git clone https://github.com/TU-USUARIO/duck-banner.git
cd duck-banner
chmod +x duck.sh
./duck.sh
```

Sin color (solo letras/numeros):
```bash
./duck.sh --no-color
```

Para ponerlo en tu .bashrc / .zshrc y que salga al abrir la terminal:
```bash
echo "~/duck-banner/duck.sh" >> ~/.bashrc
```

## Archivos
- `duck.sh` - El banner. No necesita dependencias, solo bash.
- `duck_ascii.txt` - Version en texto plano.

Hecho a partir de la imagen del pato azul con pico amarillo y ojos morados.
